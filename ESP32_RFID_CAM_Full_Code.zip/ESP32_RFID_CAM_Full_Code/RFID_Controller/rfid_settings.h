#pragma once
#include <stdint.h>

// Settings copied from the sketch you supplied.
constexpr char WIFI_SSID[] = "thiraphat";
constexpr char WIFI_PASS[] = "12345678";
constexpr char SERVER_URL[] = "http://192.168.137.1:3001/access";
constexpr char DEVICE_TOKEN[] = "a033222b56976a4d77ac32d427599ec16a2c71dac747df219475973a191ff4e5";
// Must match the [WIFI] MAC printed by ESP32-CAM (STA MAC).
constexpr uint8_t CAM_MAC[] = {0x00, 0x4B, 0x12, 0x24, 0x74, 0x00};

constexpr int SS_IN=5, RST_IN=4, SCK_IN=18, MISO_IN=19, MOSI_IN=23;
constexpr int SS_OUT=17, RST_OUT=2, SCK_OUT=14, MISO_OUT=35, MOSI_OUT=13;
constexpr int RELAY_PIN=25, TRIG_PIN=26, ECHO_PIN=27, BUZZER_PIN=33;
constexpr bool RELAY_ACTIVE_HIGH = true; // Set false for an active-LOW relay module.
constexpr uint32_t RELAY_OPEN_MS=5000, PRESENCE_HEARTBEAT_MS=1000;
constexpr uint32_t SENSOR_INTERVAL_MS=100, PRESENCE_ENTER_MS=200, PRESENCE_EXIT_MS=500;
constexpr float WAKE_DISTANCE_CM=45.0f, LEAVE_DISTANCE_CM=50.0f;
constexpr uint32_t MAX_SCAN_RESULT_AGE_MS=10000;
// Restarts can help a disturbed reader recover, but do not fix supply/solenoid noise.
constexpr bool REINIT_READERS_AFTER_UNLOCK = false;
