#pragma once
#include <stdint.h>
#include <cstring>

inline bool elapsedMs(uint32_t now, uint32_t since, uint32_t interval) {
  return uint32_t(now - since) >= interval;
}

// Only explicit supported fields grant access. A present but invalid `granted`
// field fails closed; explicit false takes precedence over status.
inline bool accessAllowed(bool hasGranted, bool grantedIsBool, bool granted,
                          const char *status) {
  if (hasGranted) return grantedIsBool && granted;
  if (!status) return false;
  return std::strcmp(status, "granted") == 0 || std::strcmp(status, "GRANTED") == 0 ||
         std::strcmp(status, "OPEN") == 0 || std::strcmp(status, "open") == 0;
}

struct PresenceFilter {
  bool present=false, candidate=false;
  uint32_t candidateSince=0;
  bool update(bool measured, uint32_t now, uint32_t enterMs, uint32_t exitMs) {
    if (candidate != measured) { candidate=measured; candidateSince=now; }
    if (candidate != present && elapsedMs(now, candidateSince, candidate ? enterMs : exitMs)) {
      present=candidate;
      return true;
    }
    return false;
  }
};
