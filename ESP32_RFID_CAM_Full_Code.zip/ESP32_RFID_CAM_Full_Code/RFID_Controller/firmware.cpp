#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <MFRC522v2.h>
#include <MFRC522DriverSPI.h>
#include <MFRC522DriverPinSimple.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <esp_now.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <cstring>
#include "rfid_settings.h"
#include "access_logic.h"

SPIClass spiIn(VSPI), spiOut(HSPI);
MFRC522DriverPinSimple ssIn(SS_IN), ssOut(SS_OUT);
MFRC522DriverSPI driverIn(ssIn, spiIn), driverOut(ssOut, spiOut);
MFRC522 rfidIn(driverIn), rfidOut(driverOut);
Adafruit_SH1106G display(128,64,&Wire,-1);

struct ScanJob { uint32_t id, created; char uid[21]; bool entry; };
enum class ScanDecision : uint8_t { Error, Denied, Granted };
struct ScanResult {
  uint32_t id, created;
  bool entry;
  ScanDecision decision;
  char name[64], message[64];
};
QueueHandle_t requestQueue=nullptr, resultQueue=nullptr;
bool oledReady=false, readerInReady=false, readerOutReady=false;
bool espNowReady=false, workerReady=false, scanPending=false;
bool relayOn=false, buzzerOn=false, displayDirty=true;
bool effectActive=false, lastWifiConnected=false;
uint32_t relaySince=0, buzzerSince=0, buzzerDuration=0;
uint32_t effectSince=0, effectDuration=0, nextJobId=0, pendingJobId=0;
uint32_t lastSensorAt=0, lastRfidAt=0, lastPresenceSentAt=0, lastEspNowAttempt=0;
bool sentPresenceOnce=false;
int lastSentPresence=-1;
PresenceFilter presence;
float distanceCm=0;

void show(const String &a, const String &b="", const String &c="") {
  if (!oledReady) return;
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(SH110X_WHITE);
  display.setCursor(0,10); display.println(a); display.println(b); display.println(c);
  display.display();
}
void setRelay(bool on) {
  digitalWrite(RELAY_PIN, (on == RELAY_ACTIVE_HIGH) ? HIGH : LOW);
  relayOn=on;
}
void startBeep(uint32_t duration) {
  buzzerOn=true; buzzerSince=millis(); buzzerDuration=duration;
  digitalWrite(BUZZER_PIN,HIGH);
}
void showEffect(const String &a, const String &b, const String &c, uint32_t duration) {
  show(a,b,c); effectActive=true; effectSince=millis(); effectDuration=duration;
}
void resetReaderPin(int pin) {
  pinMode(pin,OUTPUT); digitalWrite(pin,LOW); delay(2);
  digitalWrite(pin,HIGH); delay(50);
}
bool initReader(MFRC522 &reader, const char *name) {
  for (int i=0; i<3; ++i) {
    if (reader.PCD_Init()) { Serial.printf("[RFID] %s ready\n",name); return true; }
    delay(50);
  }
  Serial.printf("[RFID] %s init failed\n",name); return false;
}
void serviceOutputs() {
  const uint32_t now=millis();
  if (buzzerOn && elapsedMs(now,buzzerSince,buzzerDuration)) {
    digitalWrite(BUZZER_PIN,LOW); buzzerOn=false;
  }
  if (relayOn && elapsedMs(now,relaySince,RELAY_OPEN_MS)) {
    setRelay(false); Serial.println("[RELAY] Locked");
    if (REINIT_READERS_AFTER_UNLOCK) {
      readerInReady=initReader(rfidIn,"IN"); readerOutReady=initReader(rfidOut,"OUT");
    }
  }
  if (effectActive && elapsedMs(now,effectSince,effectDuration)) {
    effectActive=false; displayDirty=true;
  }
}

bool setupEspNow() {
  if (esp_now_init()!=ESP_OK) return false;
  esp_now_peer_info_t peer={};
  memcpy(peer.peer_addr,CAM_MAC,6);
  peer.channel=0; peer.ifidx=WIFI_IF_STA; peer.encrypt=false;
  const esp_err_t err=esp_now_add_peer(&peer);
  if (err!=ESP_OK && err!=ESP_ERR_ESPNOW_EXIST) {
    esp_now_deinit(); return false;
  }
  Serial.println("[ESP-NOW] Ready; current WiFi channel, STA interface");
  return true;
}
void servicePresenceSend() {
  const uint32_t now=millis();
  if (!espNowReady && elapsedMs(now,lastEspNowAttempt,3000)) {
    lastEspNowAttempt=now; espNowReady=setupEspNow();
  }
  if (!espNowReady) return;
  const uint8_t command=presence.present ? 1 : 0;
  if (sentPresenceOnce && command==lastSentPresence &&
      !elapsedMs(now,lastPresenceSentAt,PRESENCE_HEARTBEAT_MS)) return;
  // Throttle failed sends too; heartbeat retries with the latest state.
  if (sentPresenceOnce && !elapsedMs(now,lastPresenceSentAt,100)) return;
  const esp_err_t err=esp_now_send(CAM_MAC,&command,1);
  const bool changed=command!=lastSentPresence;
  lastPresenceSentAt=now; sentPresenceOnce=true;
  if (err==ESP_OK) {
    lastSentPresence=command;
    if (changed) Serial.printf("[ESP-NOW] Queued presence=%u (not a delivery ACK)\n",command);
  } else {
    // Mark attempted state so errors retry at heartbeat interval, not every loop.
    lastSentPresence=command;
    Serial.printf("[ESP-NOW] Queue error: %s\n",esp_err_to_name(err));
  }
}
void serviceUltrasonic() {
  const uint32_t now=millis();
  if (!elapsedMs(now,lastSensorAt,SENSOR_INTERVAL_MS)) return;
  lastSensorAt=now;
  digitalWrite(TRIG_PIN,LOW); delayMicroseconds(2);
  digitalWrite(TRIG_PIN,HIGH); delayMicroseconds(10); digitalWrite(TRIG_PIN,LOW);
  const uint32_t duration=pulseIn(ECHO_PIN,HIGH,20000);
  distanceCm=duration ? duration*0.0343f/2.0f : 0;
  const bool measured=duration && distanceCm <= (presence.present ? LEAVE_DISTANCE_CM : WAKE_DISTANCE_CM);
  if (presence.update(measured,millis(),PRESENCE_ENTER_MS,PRESENCE_EXIT_MS)) {
    displayDirty=true;
    Serial.printf("[PRESENCE] %s distance=%.1f cm\n",presence.present ? "nearby" : "absent",distanceCm);
  }
}

// Worker task owns HTTP. It never touches SPI, OLED, relay or the buzzer.
void requestAccess(const ScanJob &job, ScanResult &result) {
  result={}; result.id=job.id; result.created=job.created; result.entry=job.entry;
  result.decision=ScanDecision::Error;
  strlcpy(result.name,"User",sizeof(result.name));
  strlcpy(result.message,"Server unavailable",sizeof(result.message));
  if (WiFi.status()!=WL_CONNECTED) {
    strlcpy(result.message,"WiFi disconnected",sizeof(result.message)); return;
  }
  HTTPClient http;
  http.setConnectTimeout(1500); http.setTimeout(3000);
  if (!http.begin(SERVER_URL)) return;
  http.addHeader("Content-Type","application/json");
  http.addHeader("Authorization",String("Bearer ")+DEVICE_TOKEN);
#if ARDUINOJSON_VERSION_MAJOR >= 7
  JsonDocument request;
#else
  StaticJsonDocument<192> request;
#endif
  request["uid"]=job.uid; request["direction"]=job.entry ? "in" : "out";
  String payload; serializeJson(request,payload);
  const int code=http.POST(payload);
  Serial.printf("[HTTP] /access code=%d gate=%s\n",code,job.entry ? "IN" : "OUT");
  if (code==200 || code==201) {
    const String body=http.getString();
#if ARDUINOJSON_VERSION_MAJOR >= 7
    JsonDocument response;
#else
    StaticJsonDocument<2048> response;
#endif
    if (body.length()>2048 || deserializeJson(response,body)) {
      strlcpy(result.message,"Invalid server JSON",sizeof(result.message));
    } else {
      JsonVariantConst grant=response["granted"];
      const bool hasGranted=!grant.isUnbound();
      const char *status=response["status"].is<const char*>() ? response["status"].as<const char*>() : nullptr;
      const bool granted=accessAllowed(hasGranted,grant.is<bool>(),grant.as<bool>(),status);
      result.decision=granted ? ScanDecision::Granted : ScanDecision::Denied;
      const char *name=response["name"] | "User";
      strlcpy(result.name,name,sizeof(result.name));
    }
  } else if (code==401) {
    strlcpy(result.message,"401: Invalid token",sizeof(result.message));
  } else if (code==403) {
    result.decision=ScanDecision::Denied;
  } else {
    snprintf(result.message,sizeof(result.message),"Server error: %d",code);
  }
  http.end();
}
void networkTask(void *) {
  uint32_t lastReconnect=millis();
  for (;;) {
    if (WiFi.status()!=WL_CONNECTED && elapsedMs(millis(),lastReconnect,15000)) {
      lastReconnect=millis(); WiFi.reconnect();
    }
    ScanJob job;
    if (xQueueReceive(requestQueue,&job,pdMS_TO_TICKS(100))==pdTRUE) {
      ScanResult result; requestAccess(job,result);
      xQueueOverwrite(resultQueue,&result);
    }
  }
}
void serviceScanResult() {
  ScanResult result;
  if (!resultQueue || xQueueReceive(resultQueue,&result,0)!=pdTRUE) return;
  if (!scanPending || result.id!=pendingJobId) return;
  scanPending=false;
  const String gate=result.entry ? "Gate: IN" : "Gate: OUT";
  if (elapsedMs(millis(),result.created,MAX_SCAN_RESULT_AGE_MS)) {
    showEffect("REQUEST EXPIRED","Please scan again",gate,1500); return;
  }
  if (result.decision==ScanDecision::Granted) {
    relaySince=millis(); setRelay(true); startBeep(200);
    showEffect("ACCESS GRANTED",result.name,gate,RELAY_OPEN_MS);
    Serial.println("[RELAY] Unlocked for 5000 ms");
  } else if (result.decision==ScanDecision::Denied) {
    startBeep(3000); showEffect("ACCESS DENIED",result.name,gate,3000);
  } else {
    showEffect("SERVER ERROR",result.message,gate,1500);
  }
  // Presence state is deliberately never modified here.
}
void processRFID(MFRC522 &reader, bool entry) {
  if (scanPending || relayOn || effectActive || !workerReady) return;
  if (!reader.PICC_IsNewCardPresent() || !reader.PICC_ReadCardSerial()) return;
  ScanJob job={}; job.id=++nextJobId; job.created=millis(); job.entry=entry;
  for (byte i=0; i<reader.uid.size && i<10; ++i)
    snprintf(job.uid+2*i,sizeof(job.uid)-2*i,"%02X",reader.uid.uidByte[i]);
  reader.PICC_HaltA(); reader.PCD_StopCrypto1();
  if (xQueueSend(requestQueue,&job,0)!=pdTRUE) {
    showEffect("BUSY","Please scan again","",1000); return;
  }
  pendingJobId=job.id; scanPending=true;
  show(entry ? "Scanning [IN]" : "Scanning [OUT]",String("UID: ")+job.uid,"Checking...");
}
void refreshDisplay() {
  if (!displayDirty || scanPending || effectActive) return;
  displayDirty=false;
  if (!workerReady) { show("NETWORK TASK ERROR","Restart controller"); return; }
  if (!readerInReady || !readerOutReady) {
    show("RFID INIT ERROR",readerInReady ? "IN: OK" : "IN: FAILED",readerOutReady ? "OUT: OK" : "OUT: FAILED"); return;
  }
  if (presence.present) show("== READY TO SCAN ==","Tap your RFID card",WiFi.status()==WL_CONNECTED ? "WiFi: OK" : "WiFi: reconnecting");
  else show("== STANDBY ==","Please come closer","OUT reader is ready");
}
void controllerSetup() {
  Serial.begin(115200);
  // Keep brownout protection enabled. Fix inadequate power/noise in hardware.
  digitalWrite(RELAY_PIN,RELAY_ACTIVE_HIGH ? LOW : HIGH); pinMode(RELAY_PIN,OUTPUT); setRelay(false);
  pinMode(BUZZER_PIN,OUTPUT); digitalWrite(BUZZER_PIN,LOW);
  pinMode(TRIG_PIN,OUTPUT); digitalWrite(TRIG_PIN,LOW); pinMode(ECHO_PIN,INPUT);
  Wire.begin(21,22); Wire.setClock(100000); Wire.setTimeOut(30);
  oledReady=display.begin(0x3c,true);
  if (!oledReady) Serial.println("[OLED] Init failed; running without display");
  show("System starting...");
  pinMode(SS_IN,OUTPUT); digitalWrite(SS_IN,HIGH);
  pinMode(SS_OUT,OUTPUT); digitalWrite(SS_OUT,HIGH);
  resetReaderPin(RST_IN); resetReaderPin(RST_OUT);
  spiIn.begin(SCK_IN,MISO_IN,MOSI_IN,SS_IN); spiOut.begin(SCK_OUT,MISO_OUT,MOSI_OUT,SS_OUT);
  readerInReady=initReader(rfidIn,"IN"); readerOutReady=initReader(rfidOut,"OUT");
  WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(true);
  WiFi.begin(WIFI_SSID,WIFI_PASS); // Do not wait for WiFi in the hardware loop.
  Serial.printf("[RFID] STA MAC=%s\n",WiFi.macAddress().c_str());
  espNowReady=setupEspNow(); lastEspNowAttempt=millis();
  requestQueue=xQueueCreate(1,sizeof(ScanJob)); resultQueue=xQueueCreate(1,sizeof(ScanResult));
  if (requestQueue && resultQueue)
    workerReady=xTaskCreate(networkTask,"rfid-http",8192,nullptr,1,nullptr)==pdPASS;
  if (!workerReady) Serial.println("[FATAL] Cannot start network worker; relay stays locked");
  displayDirty=true; refreshDisplay(); servicePresenceSend();
}
void controllerLoop() {
  serviceOutputs(); serviceScanResult(); serviceUltrasonic(); serviceOutputs(); servicePresenceSend();
  const bool connected=WiFi.status()==WL_CONNECTED;
  if (connected!=lastWifiConnected) {
    lastWifiConnected=connected; displayDirty=true;
    if (connected) {
      Serial.printf("[WIFI] IP=%s MAC=%s channel=%d\n",WiFi.localIP().toString().c_str(),WiFi.macAddress().c_str(),int(WiFi.channel()));
      sentPresenceOnce=false; // Re-sync promptly after switching to AP's channel.
    }
  }
  if (elapsedMs(millis(),lastRfidAt,40)) {
    lastRfidAt=millis();
    if (presence.present && readerInReady) processRFID(rfidIn,true);
    if (readerOutReady) processRFID(rfidOut,false);
  }
  refreshDisplay(); delay(2);
}
