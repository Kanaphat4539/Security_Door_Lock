#pragma once
#include <stdint.h>

struct PresenceSnapshot {
  int command=-1;
  uint32_t changedAt=0, receivedAt=0, revision=0;
  bool received=false;
};
inline bool presenceLinkFresh(const PresenceSnapshot &s, uint32_t now, uint32_t timeoutMs) {
  return s.received && uint32_t(now-s.receivedAt)<timeoutMs;
}
inline bool nextPresenceDemand(bool previous, const PresenceSnapshot &s, uint32_t now,
                               uint32_t debounceMs, uint32_t absenceMs, uint32_t timeoutMs) {
  if (!presenceLinkFresh(s,now,timeoutMs)) return false;
  const uint32_t stableFor=uint32_t(now-s.changedAt);
  if (s.command==1 && stableFor>=debounceMs) return true;
  if (s.command==0 && stableFor>=absenceMs) return false;
  return previous;
}
// Presence event is debounced independently from the camera's absence grace.
// -1 means no stable event yet; a lost link synthesizes an absent event.
inline int stablePresenceEvent(const PresenceSnapshot &s, uint32_t now,
                               uint32_t debounceMs, uint32_t timeoutMs) {
  if (!s.received) return -1;
  if (!presenceLinkFresh(s,now,timeoutMs)) return 0;
  return uint32_t(now-s.changedAt)>=debounceMs ? s.command : -1;
}
