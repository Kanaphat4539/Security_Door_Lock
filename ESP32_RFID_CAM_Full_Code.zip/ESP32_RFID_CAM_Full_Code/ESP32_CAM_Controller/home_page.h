#pragma once
#include <Arduino.h>
const char kHomePage[] PROGMEM=R"HTML(<!doctype html>
<html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ESP32-CAM Live</title><style>
:root{color-scheme:light dark}body{font:16px system-ui;max-width:800px;margin:24px auto;padding:0 16px}
button{padding:10px 16px;margin:0 8px 8px 0;cursor:pointer}canvas{max-width:100%;height:auto;border-radius:8px}
pre{font-size:13px;white-space:pre-wrap;overflow-wrap:anywhere}#message{min-height:2em}
</style></head><body><h2>ESP32-CAM Live</h2>
<p>กล้องตื่นเมื่อเปิดดูภาพหรือมีคนเข้าใกล้ และพักเมื่อไม่มีทั้งสองอย่าง</p>
<p>VGA · JPEG quality 10 · เป้าหมาย 10 FPS เมื่อมี PSRAM · ดูได้ครั้งละหนึ่งหน้าต่าง</p>
<button id="startButton">เริ่มดู / เชื่อมต่อใหม่</button><button id="stopButton">หยุดดู</button>
<p id="message">กดเริ่มดูเพื่อเปิดภาพสด</p>
<canvas id="feed" width="640" height="480" style="display:none" role="img" aria-label="Live camera"></canvas>
<details><summary>สถานะระบบ</summary><pre id="status"></pre></details>
<script>
const feed=document.getElementById('feed'), context=feed.getContext('2d',{alpha:false});
const message=document.getElementById('message');
let wanted=false, attempting=false, suspended=false, retryTimer=null;
let viewerId=0, action=0, session=null, resumeWhenVisible=false, startPending=false;

class MjpegReader {
  constructor(onFrame) { this.buffer=new Uint8Array(0); this.needed=null; this.onFrame=onFrame; }
  push(chunk) {
    const joined=new Uint8Array(this.buffer.length+chunk.length);
    joined.set(this.buffer); joined.set(chunk,this.buffer.length); this.buffer=joined;
    while (true) {
      if (this.needed===null) {
        let end=-1;
        for(let i=0;i+3<this.buffer.length;++i)
          if(this.buffer[i]===13 && this.buffer[i+1]===10 && this.buffer[i+2]===13 && this.buffer[i+3]===10) { end=i; break; }
        if(end<0) { if(this.buffer.length>4096) throw new Error('Invalid MJPEG header'); return; }
        const header=new TextDecoder().decode(this.buffer.subarray(0,end));
        const match=/(?:^|\r\n)Content-Length:\s*(\d+)\s*(?:\r\n|$)/i.exec(header);
        const length=match ? Number(match[1]) : 0;
        if(length<4 || length>512*1024) throw new Error('Invalid JPEG length');
        this.needed=length; this.buffer=this.buffer.subarray(end+4);
      }
      if(this.buffer.length<this.needed) return;
      const jpeg=this.buffer.slice(0,this.needed);
      this.buffer=this.buffer.subarray(this.needed); this.needed=null;
      if(jpeg[0]===255 && jpeg[1]===216 && jpeg[jpeg.length-2]===255 && jpeg[jpeg.length-1]===217)
        this.onFrame(jpeg);
    }
  }
}
function detach(hide=true) {
  if(session) { session.pending=null; session.abort.abort(); }
  session=null;
  if(hide) feed.style.display='none';
}
function releaseViewer(id) {
  if(id) void fetch('/viewer/stop?viewer='+id,{method:'POST',keepalive:true}).catch(()=>{});
}
function stop() {
  const old=viewerId;
  ++action; viewerId=0; resumeWhenVisible=false; startPending=false;
  wanted=false; attempting=false; suspended=false;
  clearTimeout(retryTimer); retryTimer=null;
  detach(); releaseViewer(old);
  message.textContent='หยุดดูแล้ว กล้องจะพักเมื่อไม่มีคนอยู่ใกล้';
}
async function decodeJpeg(bytes) {
  const blob=new Blob([bytes],{type:'image/jpeg'});
  if(typeof createImageBitmap==='function') return createImageBitmap(blob);
  return new Promise((resolve,reject)=>{
    const image=new Image(), url=URL.createObjectURL(blob);
    image.onload=()=>{URL.revokeObjectURL(url);resolve(image);};
    image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('JPEG decode failed'));};
    image.src=url;
  });
}
async function drawLatest(run) {
  run.decoding=true;
  try {
    while(session===run && run.pending) {
      const bytes=run.pending; run.pending=null;
      let bitmap;
      try {
        bitmap=await decodeJpeg(bytes);
        if(session!==run) break;
        if(feed.width!==bitmap.width || feed.height!==bitmap.height) {feed.width=bitmap.width;feed.height=bitmap.height;}
        context.drawImage(bitmap,0,0); feed.style.display='block';
        ++run.drawn; run.lastPaint=Date.now();
      } catch(_) {++run.decodeErrors;}
      finally {if(bitmap && bitmap.close) bitmap.close();}
    }
  } finally {run.decoding=false;}
}
async function receiveStream(url,run) {
  const response=await fetch(url,{cache:'no-store',signal:run.abort.signal});
  if(!response.ok || !response.body) throw new Error('Stream unavailable');
  const parser=new MjpegReader(bytes=>{
    if(session!==run) return;
    ++run.received;
    if(run.pending) ++run.skipped;
    run.pending=bytes;
    if(!run.decoding) void drawLatest(run);
  });
  const reader=response.body.getReader();
  try {
    while(session===run) {
      const {value,done}=await reader.read();
      if(done) throw new Error('Stream ended');
      parser.push(value);
    }
  } finally {try {await reader.cancel();}catch(_){} reader.releaseLock();}
}
function connectStream() {
  retryTimer=null;
  if(!wanted || suspended || document.hidden) return;
  detach(false); attempting=true;
  const now=Date.now();
  const run={abort:new AbortController(),pending:null,decoding:false,received:0,drawn:0,skipped:0,
    decodeErrors:0,lastPaint:now,sampleAt:now,sampleDrawn:0};
  session=run;
  const url=new URL(location.href);
  url.port='81'; url.pathname='/stream'; url.search='?viewer='+viewerId+'&t='+now; url.hash='';
  message.textContent='กำลังเชื่อมต่อ...';
  void receiveStream(url.toString(),run).catch(()=>{
    if(session===run) scheduleRetry('ภาพขาดหาย กำลังเชื่อมต่อใหม่...');
  });
}
function scheduleRetry(text) {
  if(!wanted || suspended || retryTimer!==null) return;
  attempting=false; detach(false); message.textContent=text;
  retryTimer=setTimeout(connectStream,500);
}
async function start() {
  stop();
  if(document.hidden) {resumeWhenVisible=true;return;}
  startPending=true;
  const thisAction=action;
  message.textContent='กำลังเปิดกล้อง...';
  const abort=new AbortController(), timer=setTimeout(()=>abort.abort(),4000);
  try {
    const response=await fetch('/viewer/start',{method:'POST',signal:abort.signal});
    if(!response.ok) throw new Error('Cannot select viewer');
    const s=await response.json();
    if(thisAction!==action || document.hidden) {releaseViewer(s.viewerId);return;}
    viewerId=s.viewerId; wanted=true; connectStream();
  } catch(_) {if(thisAction===action) message.textContent='ติดต่อกล้องไม่ได้ กดเริ่มดูเพื่อลองใหม่';}
  finally {clearTimeout(timer);if(thisAction===action) startPending=false;}
}
async function pollStatus() {
  const expectedViewer=viewerId, abort=new AbortController();
  const timer=setTimeout(()=>abort.abort(),2500);
  try {
    if(wanted && expectedViewer && !document.hidden)
      await fetch('/viewer/heartbeat?viewer='+expectedViewer,{method:'POST',signal:abort.signal});
    const response=await fetch('/status',{cache:'no-store',signal:abort.signal});
    if(!response.ok) throw new Error('Status unavailable');
    const s=await response.json();
    if(session) {s.browserReceived=session.received;s.browserDisplayed=session.drawn;s.browserSkipped=session.skipped;s.browserDecodeErrors=session.decodeErrors;}
    document.getElementById('status').textContent=JSON.stringify(s,null,2);
    if(wanted && expectedViewer===viewerId && expectedViewer!==0) {
      if(s.selectedViewer!==viewerId) {
        stop(); message.textContent='มีหน้าต่างอื่นเริ่มดู หรือกล้องรีสตาร์ต กดเริ่มดูอีกครั้ง';
      } else if(s.manualSleep) {
        suspended=true; attempting=false; clearTimeout(retryTimer); retryTimer=null; detach();
        message.textContent='พักกล้องด้วยตนเอง ส่ง w ใน Serial Monitor เพื่อเปิดใช้งาน';
      } else if(suspended) {suspended=false;connectStream();}
      else if(attempting && session) {
        const run=session, now=Date.now();
        if(run.drawn>run.sampleDrawn) {
          const fps=(run.drawn-run.sampleDrawn)*1000/Math.max(1,now-run.sampleAt);
          message.textContent='Live: '+fps.toFixed(1)+' FPS | '+s.resolution+' | JPEG quality '+s.jpegQuality;
        }
        run.sampleAt=now;run.sampleDrawn=run.drawn;
        if(now-run.lastPaint>(run.drawn ? 4000 : 12000)) scheduleRetry('ยังไม่มีภาพใหม่ กำลังเชื่อมต่อใหม่...');
      }
    }
  } catch(_) {
    if(wanted && attempting && session && Date.now()-session.lastPaint>12000)
      scheduleRetry('การเชื่อมต่อขาดหาย กำลังลองใหม่...');
  } finally {clearTimeout(timer);setTimeout(pollStatus,2000);}
}
document.getElementById('startButton').addEventListener('click',start);
document.getElementById('stopButton').addEventListener('click',stop);
document.addEventListener('visibilitychange',()=>{
  if(document.hidden) {const resume=wanted || startPending;stop();resumeWhenVisible=resume;}
  else if(resumeWhenVisible) {resumeWhenVisible=false;void start();}
});
window.addEventListener('pagehide',stop);
pollStatus();
</script></body></html>)HTML";
