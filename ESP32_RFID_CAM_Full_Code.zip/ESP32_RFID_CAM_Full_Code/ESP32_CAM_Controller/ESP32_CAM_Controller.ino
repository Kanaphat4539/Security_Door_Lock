// Open this file in Arduino IDE. Keep all files in this folder together.
void cameraSetup();
void cameraLoop();
void setup() { cameraSetup(); }
void loop() { cameraLoop(); }
