#pragma once
#include <stdint.h>

// Same WiFi/backend as the RFID sketch. Base URL has NO trailing /access.
constexpr char kWifiSsid[]="thiraphat";
constexpr char kWifiPassword[]="12345678";
constexpr char kServerBase[]="http://192.168.137.1:3001";
constexpr char kDeviceToken[]="a033222b56976a4d77ac32d427599ec16a2c71dac747df219475973a191ff4e5";
constexpr char kHostname[]="kmitl-cam";

// Optional: enter the RFID board's STA MAC and change to true to restrict senders.
constexpr bool kFilterSenderMac=false;
constexpr uint8_t kSenderMac[]={0,0,0,0,0,0};
constexpr bool kDashboardOnly=false;
constexpr uint32_t kPresenceDebounceMs=300;
constexpr uint32_t kAbsenceSleepMs=5000;
constexpr uint32_t kPresenceLinkTimeoutMs=5000;
constexpr uint32_t kViewerLeaseMs=8000;
constexpr uint32_t kPresenceRetryMs=3000, kPresenceWakeRetryMs=3000;
constexpr uint32_t kFrameIntervalMs=100;
constexpr int kJpegQuality=10;
