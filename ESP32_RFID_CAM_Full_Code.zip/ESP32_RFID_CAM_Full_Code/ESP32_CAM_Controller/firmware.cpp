#include <Arduino.h>
#include <WiFi.h>
#include <ESPmDNS.h>
#include <HTTPClient.h>
#include <esp_camera.h>
#include <esp_http_server.h>
#include <esp_now.h>
#include <esp_idf_version.h>
#include <esp_heap_caps.h>
#include <esp_system.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <atomic>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <lwip/sockets.h>
#include <lwip/tcp.h>
#include "cam_settings.h"
#include "presence_logic.h"
#include "home_page.h"

// AI-Thinker ESP32-CAM / OV2640; GPIO4 flash remains off.
constexpr int PWDN=32;
SemaphoreHandle_t cameraMutex=nullptr;
std::atomic<bool> cameraOn{false}, cameraReady{false}, streamActive{false}, manualSleep{false};
std::atomic<bool> presenceDemand{false}, mdnsStarted{false};
std::atomic<uint32_t> pendingCaptures{0}, selectedViewer{0}, activeViewer{0}, lastViewerHeartbeat{0};
std::atomic<uint32_t> streamFrames{0}, lastStreamFrameMs{0}, streamFpsTenths{0};
std::atomic<uint32_t> frameFetchMs{0}, frameSendMs{0}, peakFetchMs{0}, peakSendMs{0};
std::atomic<uint32_t> jpegBytes{0}, droppedFrames{0}, cameraRecoveries{0};
bool hasPsram=false;
httpd_handle_t controlServer=nullptr, streamServer=nullptr;
portMUX_TYPE presenceMux=portMUX_INITIALIZER_UNLOCKED;
PresenceSnapshot receivedPresence;

PresenceSnapshot presenceSnapshot() {
  portENTER_CRITICAL(&presenceMux);
  const PresenceSnapshot s=receivedPresence;
  portEXIT_CRITICAL(&presenceMux);
  return s;
}
bool presenceWantsCamera() {
  if (kDashboardOnly) return false;
  return nextPresenceDemand(presenceDemand.load(),presenceSnapshot(),millis(),
                            kPresenceDebounceMs,kAbsenceSleepMs,kPresenceLinkTimeoutMs);
}
int backendPresenceState() {
  if (kDashboardOnly) return -1;
  return stablePresenceEvent(presenceSnapshot(),millis(),kPresenceDebounceMs,kPresenceLinkTimeoutMs);
}
struct CameraLock {
  bool acquired;
  explicit CameraLock(uint32_t ms=1500)
    : acquired(cameraMutex && xSemaphoreTake(cameraMutex,pdMS_TO_TICKS(ms))==pdTRUE) {}
  ~CameraLock() { if (acquired) xSemaphoreGive(cameraMutex); }
};
// Callers hold cameraMutex for ALL driver access, including init/deinit.
bool sleepCameraLocked() {
  cameraReady.store(false);
  if (cameraOn.load()) {
    const esp_err_t err=esp_camera_deinit();
    if (err!=ESP_OK) { Serial.printf("[CAM] deinit failed: %s\n",esp_err_to_name(err)); return false; }
    cameraOn.store(false); Serial.println("[CAM] Sensor asleep; WiFi/ESP-NOW stay on");
  }
  pinMode(PWDN,OUTPUT); digitalWrite(PWDN,HIGH);
  return true;
}
bool wakeCameraLocked() {
  const bool present=presenceWantsCamera();
  if (manualSleep.load() || (!streamActive.load() && !present)) return false;
  if (present) presenceDemand.store(true);
  if (cameraOn.load()) {
    if (cameraReady.load()) return true;
    if (!sleepCameraLocked()) return false;
  }
  camera_config_t config={};
  config.ledc_channel=LEDC_CHANNEL_0; config.ledc_timer=LEDC_TIMER_0;
  config.pin_d0=5; config.pin_d1=18; config.pin_d2=19; config.pin_d3=21;
  config.pin_d4=36; config.pin_d5=39; config.pin_d6=34; config.pin_d7=35;
  config.pin_xclk=0; config.pin_pclk=22; config.pin_vsync=25; config.pin_href=23;
  config.pin_sccb_sda=26; config.pin_sccb_scl=27;
  config.pin_pwdn=PWDN; config.pin_reset=-1; config.xclk_freq_hz=20000000;
  config.pixel_format=PIXFORMAT_JPEG;
  config.frame_size=hasPsram ? FRAMESIZE_UXGA : FRAMESIZE_QVGA;
  config.jpeg_quality=kJpegQuality; config.fb_count=hasPsram ? 2 : 1;
  config.fb_location=hasPsram ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
  config.grab_mode=hasPsram ? CAMERA_GRAB_LATEST : CAMERA_GRAB_WHEN_EMPTY;
  const esp_err_t err=esp_camera_init(&config);
  if (err!=ESP_OK) {
    pinMode(PWDN,OUTPUT); digitalWrite(PWDN,HIGH);
    Serial.printf("[CAM] init failed: %s\n",esp_err_to_name(err)); return false;
  }
  cameraOn.store(true);
  sensor_t *sensor=esp_camera_sensor_get();
  if (!sensor || sensor->set_framesize(sensor,hasPsram ? FRAMESIZE_VGA : FRAMESIZE_QVGA)!=0 ||
      sensor->set_quality(sensor,kJpegQuality)!=0) {
    sleepCameraLocked(); return false;
  }
  // Warm up before allowing the network worker to advertise readiness.
  bool gotFrame=false;
  for (int i=0; i<2; ++i) {
    camera_fb_t *fb=esp_camera_fb_get();
    if (fb) { gotFrame=true; esp_camera_fb_return(fb); }
  }
  if (!gotFrame) { sleepCameraLocked(); return false; }
  cameraReady.store(true);
  Serial.printf("[CAM] Ready: %s quality=%d\n",hasPsram ? "640x480" : "320x240",kJpegQuality);
  return true;
}

struct JpegCopy {
  uint8_t *data=nullptr;
  size_t capacity=0, length=0;
  JpegCopy()=default;
  JpegCopy(const JpegCopy&)=delete;
  JpegCopy &operator=(const JpegCopy&)=delete;
  ~JpegCopy() { heap_caps_free(data); }
  bool reserve(size_t bytes) {
    if (!bytes || bytes>512*1024) return false;
    if (bytes<=capacity) return true;
    const size_t wanted=(bytes+4095)&~static_cast<size_t>(4095);
    void *p=heap_caps_realloc(data,wanted,MALLOC_CAP_8BIT | (hasPsram ? MALLOC_CAP_SPIRAM : 0));
    if (!p) return false;
    data=static_cast<uint8_t*>(p); capacity=wanted; return true;
  }
};
struct CapturePriority {
  CapturePriority() { pendingCaptures.fetch_add(1); }
  ~CapturePriority() { pendingCaptures.fetch_sub(1); }
};
size_t completeJpegLength(const uint8_t *data, size_t length) {
  if (!data || length<4 || data[0]!=0xff || data[1]!=0xd8) return 0;
  for (size_t end=length; end>=4; --end)
    if (data[end-2]==0xff && data[end-1]==0xd9) return end;
  return 0;
}
bool copyFrameLocked(JpegCopy &image, bool fresh, const char *&reason) {
  image.length=0;
  camera_fb_t *fb=esp_camera_fb_get();
  for (int stale=0; fresh && fb && stale<(hasPsram ? 2 : 1); ++stale) {
    esp_camera_fb_return(fb); fb=esp_camera_fb_get();
  }
  if (!fb) { reason="frame acquisition failed"; return false; }
  const size_t length=fb->format==PIXFORMAT_JPEG ? completeJpegLength(fb->buf,fb->len) : 0;
  const bool ok=length && image.reserve(length);
  if (ok) { memcpy(image.data,fb->buf,length); image.length=length; }
  else reason=length ? "JPEG copy allocation failed" : "invalid JPEG frame";
  esp_camera_fb_return(fb); return ok;
}
void recordPeak(std::atomic<uint32_t> &peak, uint32_t value) {
  uint32_t old=peak.load();
  while (value>old && !peak.compare_exchange_weak(old,value)) {}
}
esp_err_t unavailable(httpd_req_t *req, const char *message) {
  httpd_resp_set_status(req,"503 Service Unavailable");
  httpd_resp_set_hdr(req,"Retry-After","1");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  httpd_resp_set_hdr(req,"Cache-Control","no-store");
  httpd_resp_set_type(req,"text/plain");
  return httpd_resp_send(req,message,HTTPD_RESP_USE_STRLEN);
}
esp_err_t captureHandler(httpd_req_t *req) {
  JpegCopy image; const char *reason="unknown"; bool prepared=false;
  {
    CapturePriority priority;
    CameraLock lock;
    if (!lock.acquired) reason="camera mutex timeout";
    else if (!wakeCameraLocked()) reason="No viewer/presence, manual sleep, or camera init failed";
    else prepared=copyFrameLocked(image,true,reason);
  }
  if (!prepared) { Serial.printf("[CAPTURE] 503: %s\n",reason); return unavailable(req,reason); }
  httpd_resp_set_type(req,"image/jpeg"); httpd_resp_set_hdr(req,"Cache-Control","no-store");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  return httpd_resp_send(req,reinterpret_cast<const char*>(image.data),image.length);
}

bool parseViewer(const char *text, uint32_t &viewer) {
  if (!text || !*text || strspn(text,"0123456789")!=strlen(text)) return false;
  errno=0; char *end=nullptr;
  const unsigned long long n=strtoull(text,&end,10);
  if (errno || *end || !n || n>UINT32_MAX) return false;
  viewer=static_cast<uint32_t>(n); return true;
}
bool requestViewerId(httpd_req_t *req, uint32_t &viewer) {
  char query[96], value[16];
  return httpd_req_get_url_query_str(req,query,sizeof(query))==ESP_OK &&
    httpd_query_key_value(query,"viewer",value,sizeof(value))==ESP_OK && parseViewer(value,viewer);
}
uint32_t changeViewer() {
  uint32_t value=selectedViewer.fetch_add(1)+1;
  if (!value) value=selectedViewer.fetch_add(1)+1;
  return value;
}
esp_err_t selectViewerHandler(httpd_req_t *req) {
  const uint32_t viewer=changeViewer(); lastViewerHeartbeat.store(millis());
  char json[48]; snprintf(json,sizeof(json),"{\"viewerId\":%u}",unsigned(viewer));
  httpd_resp_set_type(req,"application/json");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  httpd_resp_set_hdr(req,"Cache-Control","no-store");
  return httpd_resp_send(req,json,HTTPD_RESP_USE_STRLEN);
}
esp_err_t stopViewerHandler(httpd_req_t *req) {
  uint32_t viewer=0;
  if (requestViewerId(req,viewer) && viewer==selectedViewer.load()) changeViewer();
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  httpd_resp_set_status(req,"204 No Content"); return httpd_resp_send(req,nullptr,0);
}
esp_err_t heartbeatViewerHandler(httpd_req_t *req) {
  uint32_t viewer=0;
  if (!requestViewerId(req,viewer) || viewer!=selectedViewer.load()) return unavailable(req,"Viewer no longer selected");
  lastViewerHeartbeat.store(millis());
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  httpd_resp_set_hdr(req,"Cache-Control","no-store");
  httpd_resp_set_status(req,"204 No Content"); return httpd_resp_send(req,nullptr,0);
}
esp_err_t statusHandler(httpd_req_t *req) {
  const PresenceSnapshot s=presenceSnapshot();
  const uint32_t now=millis(), lastFrame=lastStreamFrameMs.load();
  char json[1536];
  const int n=snprintf(json,sizeof(json),
    "{\"camera\":\"%s\",\"cameraReady\":%s,\"streamActive\":%s,\"manualSleep\":%s,\"cooling\":false,"
    "\"psram\":%s,\"resolution\":\"%s\",\"jpegQuality\":%d,\"maxFps\":%u,\"maxStreamSeconds\":0,"
    "\"idleSleepSeconds\":0,\"viewerLeaseSeconds\":%u,\"presenceCommand\":%d,\"presenceLinkFresh\":%s,"
    "\"presenceAgeMs\":%u,\"presenceKeepsAwake\":%s,\"absenceSleepSeconds\":%u,\"presenceTimeoutSeconds\":%u,"
    "\"streamFrames\":%u,\"fps\":%.1f,\"lastFrameAgeMs\":%u,\"recoveries\":%u,"
    "\"ip\":\"%s\",\"url\":\"http://%s.local/\",\"mdns\":%s,\"rssi\":%d,"
    "\"firmware\":\"presence-heartbeat-6\",\"viewerId\":%u,\"selectedViewer\":%u,"
    "\"frameFetchMs\":%u,\"frameSendMs\":%u,\"peakFetchMs\":%u,\"peakSendMs\":%u,\"jpegBytes\":%u,\"droppedFrames\":%u}",
    cameraOn.load() ? "awake" : "asleep",cameraReady.load() ? "true" : "false",
    streamActive.load() ? "true" : "false",manualSleep.load() ? "true" : "false",
    hasPsram ? "true" : "false",hasPsram ? "640x480" : "320x240",kJpegQuality,
    hasPsram ? unsigned(1000/kFrameIntervalMs) : 8u,unsigned(kViewerLeaseMs/1000),s.command,
    presenceLinkFresh(s,now,kPresenceLinkTimeoutMs) ? "true" : "false",s.received ? unsigned(now-s.receivedAt) : 0u,
    presenceWantsCamera() ? "true" : "false",unsigned(kAbsenceSleepMs/1000),unsigned(kPresenceLinkTimeoutMs/1000),
    unsigned(streamFrames.load()),streamFpsTenths.load()/10.0,lastFrame ? unsigned(now-lastFrame) : 0u,
    unsigned(cameraRecoveries.load()),WiFi.localIP().toString().c_str(),kHostname,mdnsStarted.load() ? "true" : "false",int(WiFi.RSSI()),
    unsigned(activeViewer.load()),unsigned(selectedViewer.load()),unsigned(frameFetchMs.load()),unsigned(frameSendMs.load()),unsigned(peakFetchMs.load()),unsigned(peakSendMs.load()),
    unsigned(jpegBytes.load()),unsigned(droppedFrames.load()));
  if (n<0 || n>=static_cast<int>(sizeof(json))) return unavailable(req,"Status buffer overflow");
  httpd_resp_set_type(req,"application/json"); httpd_resp_set_hdr(req,"Cache-Control","no-store");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  return httpd_resp_send(req,json,n);
}
esp_err_t streamHandler(httpd_req_t *req) {
  const uint32_t selection=selectedViewer.load();
  uint32_t viewer=0;
  char query[96], value[16];
  if (httpd_req_get_url_query_len(req)>=sizeof(query)) return unavailable(req,"Stream query too long");
  if (httpd_req_get_url_query_str(req,query,sizeof(query))==ESP_OK) {
    const esp_err_t parameter=httpd_query_key_value(query,"viewer",value,sizeof(value));
    if (parameter!=ESP_ERR_NOT_FOUND &&
        (parameter!=ESP_OK || !parseViewer(value,viewer) || viewer!=selection))
      return unavailable(req,"Invalid/replaced viewer; press Start");
  }
  if (manualSleep.load()) return unavailable(req,"Manual sleep; send w in Serial Monitor");
  bool expected=false;
  if (!streamActive.compare_exchange_strong(expected,true)) return unavailable(req,"One viewer at a time");
  activeViewer.store(viewer);
  JpegCopy image;
  if (hasPsram && !image.reserve(256*1024)) {
    activeViewer.store(0); streamActive.store(false); return unavailable(req,"Insufficient PSRAM");
  }
  const int fd=httpd_req_to_sockfd(req), noDelay=1;
  if (fd>=0) setsockopt(fd,IPPROTO_TCP,TCP_NODELAY,&noDelay,sizeof(noDelay));
  esp_err_t result=httpd_resp_set_type(req,"multipart/x-mixed-replace;boundary=camframe");
  httpd_resp_set_hdr(req,"Cache-Control","no-store, no-cache, must-revalidate");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*"); httpd_resp_set_hdr(req,"X-Accel-Buffering","no");
  const char *reason="manual sleep";
  uint32_t sampleStarted=millis(), sampleFrames=0, frames=0;
  unsigned consecutiveFailures=0, recoveryAttempts=0;
  const uint32_t interval=hasPsram ? kFrameIntervalMs : 125;
  streamFpsTenths.store(0);
  while (result==ESP_OK && !manualSleep.load()) {
    const uint32_t started=millis();
    if (selectedViewer.load()!=selection) { reason="viewer stopped/changed"; result=ESP_FAIL; break; }
    if (viewer && uint32_t(started-lastViewerHeartbeat.load())>=kViewerLeaseMs) {
      reason="viewer heartbeat expired"; result=ESP_FAIL; break;
    }
    if (WiFi.status()!=WL_CONNECTED) { reason="WiFi disconnected"; result=ESP_FAIL; break; }
    if (pendingCaptures.load()) { delay(10); continue; }
    {
      CameraLock lock(50);
      if (!lock.acquired) { delay(10); continue; }
      if (!wakeCameraLocked()) { reason="camera unavailable"; result=ESP_FAIL; break; }
      if (!copyFrameLocked(image,false,reason)) {
        droppedFrames.fetch_add(1);
        if (++consecutiveFailures<3) { delay(1); continue; }
        if (recoveryAttempts>=2 || manualSleep.load()) { result=ESP_FAIL; break; }
        ++recoveryAttempts;
        if (!sleepCameraLocked()) { result=ESP_FAIL; break; }
        delay(30);
        if (!wakeCameraLocked()) { result=ESP_FAIL; break; }
        cameraRecoveries.fetch_add(1); consecutiveFailures=0; continue;
      }
    }
    consecutiveFailures=0;
    frameFetchMs.store(millis()-started); recordPeak(peakFetchMs,frameFetchMs.load());
    jpegBytes.store(image.length);
    const uint32_t sendStarted=millis();
    char header[96];
    const int length=snprintf(header,sizeof(header),
      "\r\n--camframe\r\nContent-Type: image/jpeg\r\nContent-Length: %u\r\n\r\n",unsigned(image.length));
    if (length<0 || length>=static_cast<int>(sizeof(header))) { result=ESP_FAIL; break; }
    result=httpd_resp_send_chunk(req,header,length);
    if (result==ESP_OK) result=httpd_resp_send_chunk(req,reinterpret_cast<const char*>(image.data),image.length);
    frameSendMs.store(millis()-sendStarted); recordPeak(peakSendMs,frameSendMs.load());
    if (result!=ESP_OK) reason="client disconnected or network send failed";
    else {
      ++frames; ++sampleFrames; streamFrames.fetch_add(1);
      const uint32_t now=millis(); lastStreamFrameMs.store(now);
      const uint32_t elapsed=now-sampleStarted;
      if (elapsed>=2000) { streamFpsTenths.store(sampleFrames*10000UL/elapsed); sampleFrames=0; sampleStarted=now; }
    }
    const uint32_t elapsed=millis()-started;
    if (result==ESP_OK) delay(elapsed<interval ? interval-elapsed : 1);
  }
  if (result==ESP_OK) result=httpd_resp_send_chunk(req,nullptr,0);
  {
    CameraLock lock(6000);
    if (lock.acquired && (manualSleep.load() || !presenceWantsCamera())) sleepCameraLocked();
  }
  streamFpsTenths.store(0); activeViewer.store(0); streamActive.store(false);
  Serial.printf("[STREAM] End frames=%u reason=%s\n",unsigned(frames),reason);
  return result;
}
esp_err_t homeHandler(httpd_req_t *req) {
  httpd_resp_set_type(req,"text/html; charset=utf-8"); httpd_resp_set_hdr(req,"Cache-Control","no-store");
  return httpd_resp_send(req,kHomePage,HTTPD_RESP_USE_STRLEN);
}
esp_err_t optionsHandler(httpd_req_t *req) {
  httpd_resp_set_hdr(req,"Access-Control-Allow-Origin","*");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Methods","GET, POST, OPTIONS");
  httpd_resp_set_hdr(req,"Access-Control-Allow-Headers","Content-Type");
  httpd_resp_set_status(req,"204 No Content"); return httpd_resp_send(req,nullptr,0);
}
bool addRoute(httpd_handle_t server, const char *path, httpd_method_t method,
              esp_err_t (*handler)(httpd_req_t*)) {
  httpd_uri_t uri={}; uri.uri=path; uri.method=method; uri.handler=handler;
  return httpd_register_uri_handler(server,&uri)==ESP_OK;
}
bool startServers() {
  httpd_config_t c=HTTPD_DEFAULT_CONFIG();
  c.server_port=80; c.ctrl_port=32768; c.stack_size=8192;
  c.send_wait_timeout=2; c.recv_wait_timeout=3; c.lru_purge_enable=true;
  c.max_uri_handlers=12;
  if (httpd_start(&controlServer,&c)!=ESP_OK) return false;
  bool ok=addRoute(controlServer,"/",HTTP_GET,homeHandler) &&
    addRoute(controlServer,"/status",HTTP_GET,statusHandler) &&
    addRoute(controlServer,"/viewer/start",HTTP_POST,selectViewerHandler) &&
    addRoute(controlServer,"/viewer/stop",HTTP_POST,stopViewerHandler) &&
    addRoute(controlServer,"/viewer/heartbeat",HTTP_POST,heartbeatViewerHandler);
  if (!kDashboardOnly) ok=ok && addRoute(controlServer,"/capture",HTTP_GET,captureHandler);
  const char *paths[]={"/viewer/start","/viewer/stop","/viewer/heartbeat"};
  for (const char *path:paths) ok=ok && addRoute(controlServer,path,HTTP_OPTIONS,optionsHandler);
  if (ok) {
    c.server_port=81; c.ctrl_port=32769;
    ok=httpd_start(&streamServer,&c)==ESP_OK;
    if (ok) ok=addRoute(streamServer,"/stream",HTTP_GET,streamHandler);
  }
  if (!ok) {
    if (streamServer) { httpd_stop(streamServer); streamServer=nullptr; }
    if (controlServer) { httpd_stop(controlServer); controlServer=nullptr; }
  }
  return ok;
}

// Snapshot metadata only: callbacks never initialize the camera or use HTTP.
#if ESP_IDF_VERSION_MAJOR >= 5
void onPresence(const esp_now_recv_info_t *info, const uint8_t *data, int len) {
  const uint8_t *mac=info ? info->src_addr : nullptr;
#else
void onPresence(const uint8_t *mac, const uint8_t *data, int len) {
#endif
  if (!data || len!=1 || data[0]>1) return;
  if (kFilterSenderMac && (!mac || memcmp(mac,kSenderMac,6)!=0)) return;
  const uint32_t now=millis();
  portENTER_CRITICAL(&presenceMux);
  // Resuming after a dead sender starts a new debounce period, even for same byte.
  if (!receivedPresence.received || receivedPresence.command!=data[0] ||
      uint32_t(now-receivedPresence.receivedAt)>=kPresenceLinkTimeoutMs) {
    receivedPresence.changedAt=now; ++receivedPresence.revision;
  }
  receivedPresence.command=data[0];
  receivedPresence.receivedAt=now; // Every valid heartbeat, not just transitions.
  receivedPresence.received=true;
  portEXIT_CRITICAL(&presenceMux);
}
int postBackend(const char *path, const String &body) {
  HTTPClient http; http.setConnectTimeout(1500); http.setTimeout(2000);
  if (!http.begin(String(kServerBase)+path)) return -1;
  http.addHeader("Content-Type","application/json");
  http.addHeader("Authorization",String("Bearer ")+kDeviceToken);
  const int code=http.POST(body); http.end(); return code;
}
void backendTask(void *) {
  bool connectedBefore=false, registered=false, attemptedPresence=false;
  uint32_t lastRegister=0, lastPresenceAttempt=0;
  int sentState=-1;
  for (;;) {
    const bool connected=WiFi.status()==WL_CONNECTED;
    if (!connected) { connectedBefore=false; registered=false; sentState=-1; }
    else {
      const bool justConnected=!connectedBefore; connectedBefore=true;
      const uint32_t now=millis();
      if (justConnected || uint32_t(now-lastRegister)>=(registered ? 60000u : 3000u)) {
        lastRegister=now;
        const String body=String("{\"ip\":\"")+WiFi.localIP().toString()+"\"}";
        const int code=postBackend("/devices/cam/register",body);
        registered=code>=200 && code<300;
        Serial.printf("[REGISTER] HTTP %d\n",code);
      }
      const int desired=backendPresenceState();
      if (registered && desired>=0 && desired!=sentState &&
          (desired==0 || (cameraReady.load() && !manualSleep.load())) &&
          (!attemptedPresence || uint32_t(millis()-lastPresenceAttempt)>=kPresenceRetryMs)) {
        // Recheck latest event after a potentially slow registration request.
        if (backendPresenceState()==desired) {
          attemptedPresence=true; lastPresenceAttempt=millis();
          const int code=postBackend("/devices/cam/presence",desired ? "{\"present\":true}" : "{\"present\":false}");
          if (code>=200 && code<300) sentState=desired;
          Serial.printf("[PRESENCE] present=%d HTTP %d\n",desired,code);
        }
      }
    }
    delay(50);
  }
}
void cameraSetup() {
  Serial.begin(115200); delay(300);
  pinMode(4,OUTPUT); digitalWrite(4,LOW);
  hasPsram=psramFound(); cameraMutex=xSemaphoreCreateMutex();
  if (!cameraMutex) { Serial.println("[FATAL] Camera mutex allocation failed"); return; }
  pinMode(PWDN,OUTPUT); digitalWrite(PWDN,HIGH);
  // Random initial generation avoids an old tab matching a viewer ID after reboot.
  selectedViewer.store(esp_random() & 0x7fffffff);
  WiFi.setHostname(kHostname); WiFi.mode(WIFI_STA); WiFi.setSleep(false); WiFi.setAutoReconnect(true);
  WiFi.begin(kWifiSsid,kWifiPassword);
  if (!startServers()) Serial.println("[FATAL] HTTP server start failed");
  if (!kDashboardOnly) {
    const esp_err_t err=esp_now_init();
    if (err==ESP_OK) Serial.printf("[ESP-NOW] Receiver callback: %s\n",esp_err_to_name(esp_now_register_recv_cb(onPresence)));
    else Serial.printf("[ESP-NOW] init failed: %s\n",esp_err_to_name(err));
    if (kServerBase[0] && kDeviceToken[0] &&
        xTaskCreate(backendTask,"cam-backend",8192,nullptr,1,nullptr)!=pdPASS)
      Serial.println("[BACKEND] Worker start failed");
  }
  Serial.printf("[BOOT] PSRAM=%s; s=manual sleep, w=allow wake\n",hasPsram ? "yes" : "no");
}
void cameraLoop() {
  if (!cameraMutex) { delay(1000); return; }
  if (Serial.available()) {
    const char cmd=Serial.read();
    if (cmd=='s' || cmd=='S') { manualSleep.store(true); Serial.println("[CAM] Manual sleep requested"); }
    if (cmd=='w' || cmd=='W') { manualSleep.store(false); Serial.println("[CAM] Automatic wake allowed"); }
  }
  const bool previous=presenceDemand.load();
  const bool demand=presenceWantsCamera(); presenceDemand.store(demand);
  if (previous!=demand) Serial.printf("[PRESENCE] Camera demand=%d\n",demand);
  static bool wakeAttempted=false;
  static uint32_t lastWakeAttempt=0;
  const bool shouldWake=demand && !manualSleep.load();
  if (!shouldWake) wakeAttempted=false;
  if (shouldWake && !cameraReady.load() &&
      (!wakeAttempted || uint32_t(millis()-lastWakeAttempt)>=kPresenceWakeRetryMs)) {
    CameraLock lock(20);
    if (lock.acquired && !cameraReady.load() && presenceWantsCamera()) {
      wakeAttempted=true; lastWakeAttempt=millis(); wakeCameraLocked();
    }
  }
  if (cameraOn.load() && !streamActive.load() && !pendingCaptures.load() &&
      (manualSleep.load() || !presenceWantsCamera())) {
    CameraLock lock(20);
    if (lock.acquired && !streamActive.load() && !pendingCaptures.load() &&
        (manualSleep.load() || !presenceWantsCamera())) sleepCameraLocked();
  }
  static bool wasConnected=false;
  static uint32_t lastReconnect=0, lastMdns=0;
  const bool connected=WiFi.status()==WL_CONNECTED;
  if (!connected && wasConnected) { if (mdnsStarted.load()) MDNS.end(); mdnsStarted.store(false); }
  if (connected && !mdnsStarted.load() && (!wasConnected || uint32_t(millis()-lastMdns)>=10000)) {
    lastMdns=millis(); mdnsStarted.store(MDNS.begin(kHostname));
    if (mdnsStarted.load()) MDNS.addService("http","tcp",80);
  }
  if (connected && !wasConnected) {
    Serial.printf("[WIFI] IP=%s MAC=%s channel=%d\n",WiFi.localIP().toString().c_str(),WiFi.macAddress().c_str(),int(WiFi.channel()));
    Serial.printf("[URL] http://%s.local/ | http://%s/\n",kHostname,WiFi.localIP().toString().c_str());
  }
  if (!connected && uint32_t(millis()-lastReconnect)>=15000) { lastReconnect=millis(); WiFi.reconnect(); }
  wasConnected=connected; delay(10);
}
