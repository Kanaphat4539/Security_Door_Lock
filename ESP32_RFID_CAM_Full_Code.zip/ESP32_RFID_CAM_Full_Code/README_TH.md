# โค้ดเต็ม RFID + ESP32-CAM — Presence heartbeat v6

## เปิดและอัปโหลด

1. แตก ZIP ก่อน แล้วเก็บไฟล์ในแต่ละโฟลเดอร์ไว้ด้วยกันทั้งหมด
2. เปิด `RFID_Controller/RFID_Controller.ino` สำหรับ ESP32 30-pin เลือกบอร์ด **ESP32 Dev Module**
3. เปิด `ESP32_CAM_Controller/ESP32_CAM_Controller.ino` สำหรับกล้อง เลือก **AI Thinker ESP32-CAM**
4. โค้ดหลักอยู่ในแท็บ `firmware.cpp` ของแต่ละโฟลเดอร์ Arduino IDE จะคอมไพล์ร่วมกับ `.ino` อัตโนมัติ ไม่ต้องคัดลอกไปรวมกัน
5. ใช้แพ็กเกจบอร์ด **esp32 by Espressif Systems 3.3.2** ซึ่งใช้ในการตรวจคอมไพล์ชุดนี้
6. ติดตั้ง Library ฝั่ง RFID ผ่าน Library Manager:
   - RFID_MFRC522v2 2.0.6 (ไฟล์ include ชื่อ MFRC522v2.h)
   - ArduinoJson 7.4.3
   - Adafruit GFX Library 1.12.6
   - Adafruit SH110X 2.1.15
   - Adafruit BusIO 1.17.4 (dependency)
7. ฝั่งกล้องใช้ WiFi, ESP-NOW, HTTP server และ camera driver ที่มากับแพ็กเกจบอร์ด

## ตั้งค่าก่อนใช้

- `RFID_Controller/rfid_settings.h`: WiFi, URL `/access`, Token, MAC กล้อง, ขาต่อ และระยะตรวจจับ
- `ESP32_CAM_Controller/cam_settings.h`: WiFi, URL ฐานของ Backend, Token, ชื่อ mDNS และเวลาพักกล้อง
- ใส่ WiFi และ Token จากโค้ดที่คุณส่งมาให้แล้ว ตรวจว่าเครื่อง Backend ยังเป็น `192.168.137.1:3001`
- MAC กล้องตั้งตามเดิม `00:4B:12:24:74:00` ต้องเทียบกับ `[WIFI] MAC=...` ใน Serial Monitor ของกล้องที่ 115200 baud
- ต่อทั้งสองบอร์ดกับ WiFi 2.4 GHz ช่องเดียวกัน ตรวจค่า `channel=` จาก Serial ของทั้งสองบอร์ด ถ้าใช้เครือข่าย mesh ชื่อ WiFi เหมือนกันอาจยังอยู่คนละช่อง
- รีเลย์เดิมเป็น active-HIGH ถ้าโมดูลคุณทำงานเมื่อ LOW ให้ตั้ง `RELAY_ACTIVE_HIGH=false`
- ตัวกรอง MAC ผู้ส่งฝั่งกล้องปิดไว้เพื่อให้ใช้กับโค้ดเดิมได้ หากต้องการจำกัดผู้ส่ง ให้ใส่ MAC ของบอร์ด RFID ใน `kSenderMac` แล้วเปิด `kFilterSenderMac`

## สิ่งที่แก้

- แยกสถานะคนออกจากหน้าจอ การสแกนบัตรไม่ล้างสถานะคน
- ส่งสถานะคนแบบเดิม 1 ไบต์ (1/0) เมื่อเปลี่ยน และส่งซ้ำทุก 1 วินาที
- กรองระยะเข้า 45 ซม. ออก 50 ซม. ยืนยันเข้า 200 ms / ออก 500 ms ลดอาการสลับจาก echo หลุดสั้น ๆ
- ฝั่งกล้องยืนยันการเข้าอีก 300 ms หลังได้รับสถานะใหม่ และพักหลังรับสถานะออกคงที่ 5 วินาที เมื่อไม่มีสตรีม
- ถ้าหยุดได้รับ heartbeat ครบ 5 วินาที ให้เลิกถือว่ามีคนทันที สตรีมที่ยังเปิดอยู่ยังทำงานต่อได้
- HTTP ฝั่ง RFID และการแจ้ง Backend ฝั่งกล้องใช้ Task แยก งานเครือข่ายไม่หน่วงวงจรตรวจระยะ/จับเวลารีเลย์
- รีเลย์เปิด 5 วินาที และ Buzzer ใช้ millis() แทน delay ยาว ตัวอ่านระยะ pulseIn ยังรอ echo ได้สูงสุด 20 ms ต่อรอบ
- รับงานสแกนครั้งละหนึ่งงาน ระหว่างตรวจสิทธิ์หรือแสดงผลเปิดประตู/ปฏิเสธ จะไม่รับบัตรเพิ่ม แต่ยังตรวจคนและส่ง heartbeat
- ตรวจ JSON แบบตรงฟิลด์ ปฏิเสธค่าที่ไม่รู้จักหรือผลที่เก่าเกิน 10 วินาที
- แจ้ง Backend ว่าพบคนหลังกล้องมีเฟรมและพร้อมแล้ว มี retry เมื่อแจ้งไม่สำเร็จ
- กล้องเริ่มต้นในสถานะพักเซ็นเซอร์ WiFi/HTTP/ESP-NOW ยังทำงาน
- คง VGA/JPEG quality 10, เป้าหมาย 10 FPS เมื่อมี PSRAM; หากไม่มี PSRAM ใช้ QVGA/8 FPS
- คง `/status`, `/capture`, `/stream` และ `/viewer/start`, `/viewer/heartbeat`, `/viewer/stop`
- หน้า Live หยุดสตรีมเมื่อซ่อนแท็บหรือกดหยุด มี reconnect และแสดงภาพล่าสุดโดยไม่สะสมคิวภาพ
- ไม่ปิด brownout detector; การปิดตัวตรวจจับไม่ได้แก้ไฟตกหรือสัญญาณรบกวนจากโซลินอยด์

## รูปแบบ Backend ที่รองรับ

POST `/access` พร้อม Authorization: Bearer TOKEN และ JSON:

```json
{"uid":"A1B2C3D4","direction":"in"}
```

direction เป็น `in` หรือ `out` ผลสำเร็จต้องเป็น HTTP 200/201 และตอบ JSON รูปแบบใดรูปแบบหนึ่ง:

```json
{"status":"granted","name":"User"}
```

```json
{"status":"OPEN","name":"User"}
```

```json
{"granted":true,"name":"User"}
```

รองรับ status แบบ `granted`, `GRANTED`, `OPEN`, `open` เท่านั้น หากมีฟิลด์ `granted` จะใช้ฟิลด์นี้เป็นหลักและต้องเป็น boolean จริง (`true`/`false`) ค่า false, null, ตัวเลข หรือข้อความ ไม่เปิดประตู แม้ status เป็น OPEN
HTTP 403 ถือว่าปฏิเสธ ส่วน HTTP 401/สถานะอื่น/JSON เสีย เป็นข้อผิดพลาดและไม่เปิดประตู
ถ้า Backend ของคุณใช้ชื่อฟิลด์อื่น ให้ปรับจุดอ่านฟิลด์ใน `requestAccess()` ให้ตรงก่อนใช้งาน

กล้องเรียก:

- POST `/devices/cam/register` ด้วย `{"ip":"IP_กล้อง"}` — ลงทะเบียนเมื่อเชื่อมต่อและทุก 60 วินาที (retry 3 วินาทีหากล้มเหลว)
- POST `/devices/cam/presence` ด้วย `{"present":true}` หรือ `{"present":false}` — ส่งสถานะล่าสุดที่นิ่งแล้ว และ retry ทุก 3 วินาทีหากล้มเหลว
- ทั้งสอง endpoint ต้องตอบ 2xx; กล้องรอให้ลงทะเบียนสำเร็จก่อนแจ้ง presence

กล้องไม่ได้บันทึกภาพเอง Backend ต้องเรียก `http://IP_กล้อง/capture` และบันทึก JPEG หลังรับ presence:true อยู่แล้ว หากได้รับ 503 ให้ retry ระยะสั้นขณะคนยังอยู่/ยังอยู่ในช่วงผ่อนผัน
การแจ้ง presence เป็นสถานะล่าสุด ไม่ใช่คิวประวัติทุกการเข้าออก หาก Backend ขาดการติดต่อ เหตุการณ์สั้น ๆ ระหว่างนั้นอาจไม่ถูกบันทึก
คำสั่ง Serial `s` พักกล้องด้วยตนเอง `w` อนุญาตให้ปลุกอัตโนมัติอีกครั้ง

## ดูภาพและเช็กระบบ

- หน้า Live: `http://kmitl-cam.local/` หรือ IP ที่พิมพ์ใน Serial
- สถานะ: `http://IP_กล้อง/status` — การอ่านสถานะไม่ปลุกกล้อง
- สตรีมตรง: `http://IP_กล้อง:81/stream` — ปิด connection เมื่อหยุดดู
- `presenceLinkFresh=true` และ `presenceAgeMs` โดยทั่วไปน้อยกว่า 1000–1500 ms แสดงว่ายังได้รับ heartbeat
- ปิดหน้า Live แล้วเดินออก: กล้องควรพักประมาณ 5 วินาทีหลังฝั่ง RFID ยืนยันว่าไม่มีคน
- ถอดไฟบอร์ด RFID ขณะกล้องตื่นจากคน: กล้องควรพักหลังขาด heartbeat 5 วินาที ถ้าไม่มีสตรีม
- เปิด Live แล้วเดินออก: กล้องต้องไม่พักจนหยุดดู
- ปิด Backend แล้วสแกนบัตร: รีเลย์ต้องไม่เปิด แต่เซ็นเซอร์และ heartbeat ยังเดินต่อ
- ข้อความ `[ESP-NOW] Queued` หมายถึงรับคำสั่งเข้าคิวส่ง ยังไม่ใช่ ACK จากกล้อง ให้ตรวจ `/status` ฝั่งกล้องประกอบ

สำหรับ Dashboard ภายนอก:
POST `/viewer/start` -> viewerId; เปิด `:81/stream?viewer=ID`; POST `/viewer/heartbeat?viewer=ID` ทุก 2 วินาที; POST `/viewer/stop?viewer=ID` และยกเลิกสตรีมเมื่อปิด/ซ่อนหน้าต่าง
การตั้ง display:none อย่างเดียวไม่หยุดสตรีม ใช้ HTTP บน LAN หรือ proxy ฝั่ง Backend ให้ตรงกับข้อจำกัด mixed content ของ browser หาก Dashboard เป็น HTTPS

## ขาต่อเดิม

| อุปกรณ์ | ขา ESP32 บอร์ด RFID |
|---|---|
| RFID IN SS / RST / SCK / MISO / MOSI | 5 / 4 / 18 / 19 / 23 |
| RFID OUT SS / RST / SCK / MISO / MOSI | 17 / 2 / 14 / 35 / 13 |
| Relay / Buzzer | 25 / 33 |
| Ultrasonic TRIG / ECHO | 26 / 27 |
| OLED SDA / SCL | 21 / 22 (SH1106, 0x3C) |

ถ้าเซ็นเซอร์ ultrasonic ส่ง ECHO ระดับ 5V ต้องลดระดับลงให้เหมาะกับ GPIO 3.3V ก่อนเข้าบอร์ด การค้างเฉพาะตอนต่อโซลินอยด์ยังต้องตรวจไฟเลี้ยงและไดโอดคร่อมขดลวด; ซอฟต์แวร์ไม่สามารถแก้ไฟตกจริงได้

## การตรวจสอบ

ดู `VALIDATION.txt` สำหรับเวอร์ชันและผลตรวจ โค้ดชุดนี้ยังไม่ได้ทดสอบกับฮาร์ดแวร์จริงหรือ Backend ของคุณ จึงยังต้องตรวจ MAC, ขั้ว active ของรีเลย์ และรูปแบบ JSON จริง
